--------------------------------------------------------------------
-- �ʱ�ȭ ----------------------------------------------------------
--------------------------------------------------------------------
dofile( ".\\LuaFunc\\InstanceDungeonBase.lua" )
--------------------------------------------------------------------
--[[
AddDungeon( "WI_DUNGEON_SECRET_L" )
--{	
	SetClass( dwClass )
	SetLevel( nMinLevel, nMaxLevel )
	SetCoolTime( dwCoolTime )
	SetMonster( nType, strMonsterId, bRed, x, y, z )
			:
			:
	SetTeleportPos( nType, x, y, z )
			:
			:
--}
--]]

--[[
-- Sample
AddDungeon( "WI_DUNGEON_FL_MAS" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 155, 155 )
	SetCoolTime( MIN(1) )
	SetTeleportPos( ID_NORMAL, 695, 90, 684 ) -- �������� ������ �ʿ��� ������ ��ǥ�� �̵��Ѵ�.
	SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	SetTeleportPos( ID_BOSS, 695, 100, 684 )
	SetMonster( ID_NORMAL, "MI_CAITSITH04_1", false, 695, 90, 684 )
	SetMonster( ID_NORMAL, "MI_CAITSITH04_1", false, 695, 90, 684 )
	SetMonster( ID_NORMAL, "MI_CAITSITH04_1", false, 695, 90, 684 )
	SetMonster( ID_MIDBOSS, "MI_AIBATT1", false, 695, 90, 684 )
	SetMonster( ID_BOSS, "MI_AIBATT1", true, 695, 100, 684 )
--}
--]]

AddDungeon( "WI_INSTANCE_OMINOUS" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(30) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )
	SetMonster( ID_NORMAL, "MI_PRICKANT04", true, 1280, 101, 1640 )
	SetMonster( ID_NORMAL, "MI_MAULMOUSE04", true, 1234, 101, 1393 )
	SetMonster( ID_NORMAL, "MI_CRIPESCENTIPEDE04", true, 1089, 101, 1590 )
	SetMonster( ID_MIDBOSS, "MI_LYCANOS01", true, 1078, 101, 1359 )
	SetMonster( ID_BOSS, "MI_VEMPAIN01", true, 1079, 101, 1457 )
--}

AddDungeon( "WI_INSTANCE_OMINOUS_1" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(30) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )
	SetMonster( ID_NORMAL, "MI_PRICKANT04_1", true, 1280, 101, 1640 )
	SetMonster( ID_NORMAL, "MI_MAULMOUSE04_1", true, 1234, 101, 1393 )
	SetMonster( ID_NORMAL, "MI_CRIPESCENTIPEDE04_1", true, 1089, 101, 1590 )
	SetMonster( ID_MIDBOSS, "MI_LYCANOS01_1", true, 1078, 101, 1359 )
	SetMonster( ID_BOSS, "MI_VEMPAIN01_1", true, 1079, 101, 1457 )
--}

AddDungeon( "WI_INSTANCE_DREADFULCAVE" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(60) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )

	SetMonster( ID_MIDBOSS, "MI_DREADSTONE01", false, 928, 101, 198 )
	SetMonster( ID_MIDBOSS, "MI_DREADSTONE02", false, 1504, 101, 419 )
	SetMonster( ID_MIDBOSS, "MI_DREADSTONE03", false, 1397, 101, 893 )
	SetMonster( ID_MIDBOSS, "MI_DREADSTONE04", false, 764, 101, 867 )
	SetMonster( ID_MIDBOSS, "MI_DREADSTONE05", false, 675, 101, 560 )

	SetMonster( ID_BOSS, "MI_SKELDEVIL", true, 1809, 101, 1395 )
--}

AddDungeon( "WI_INSTANCE_RUSTIA" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(180) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )

	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE01", false, 513, 101, 953 )
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE02", false, 889, 101, 1121 )
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE03", false, 926, 101, 850 )
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE04", false, 1247, 101, 1272 )
	

	SetMonster( ID_BOSS, "MI_BESIBIGFOOT01", true, 1126, 103, 1505 )
--}

AddDungeon( "WI_INSTANCE_RUSTIA_1" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(180) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )

	
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE01", false, 513, 101, 953 )
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE02", false, 889, 101, 1121 )
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE03", false, 926, 101, 850 )
	SetMonster( ID_MIDBOSS, "MI_RUSTIACRASHGATE04", false, 1247, 101, 1272 )

	SetMonster( ID_BOSS, "MI_BESIBIGFOOT02", true, 1126, 103, 1505 )
--}
AddDungeon( "WI_INSTANCE_BEHAMAH" )	--	160H����Ħ˹���
--{
	--SetClass( CLASS_MASTER, CLASS_HERO,CLASS_LEGENDHERO )
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(180) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )

	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 697, 100, 374 )
	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 624, 100, 494 )
	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 760, 100, 637 )
	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 918, 100, 643 )
	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 579, 100, 748 )
	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 897, 100, 784 )
	SetMonster( ID_MIDBOSS, "MI_BEHESTATUE01", false, 530, 100, 834 )
	
	SetMonster( ID_BOSS, "MI_BEHEMOTH", true, 1263, 101, 1394 )
--}
AddDungeon( "WI_INSTANCE_KALGAS" )	--	160H������˹��Ѩ
--{
	--SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO,CLASS_LEGENDHERO )
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(60) )
	--SetTeleportPos( ID_NORMAL, 1358, 102, 1315 )
	--SetTeleportPos( ID_MIDBOSS, 695, 90, 684 )
	--SetTeleportPos( ID_BOSS, 695, 100, 684 )


	SetMonster( ID_MIDBOSS, "MI_KALGASAKIN01", false, 455, 304, 603 )
	SetMonster( ID_MIDBOSS, "MI_KALGASBALT01", false, 2366, 302, 894 )
	SetMonster( ID_MIDBOSS, "MI_KALGASBALT01", false, 2812, 303, 798 )
	SetMonster( ID_MIDBOSS, "MI_KALGASBALT01", false, 2166, 302, 615 )
	SetMonster( ID_MIDBOSS, "MI_KALGASBALT01", false, 2218, 303, 416 )
	SetMonster( ID_MIDBOSS, "MI_KALGASBALT01", false, 1940, 303, 354 )
	
	SetMonster( ID_BOSS, "MI_KALGASBOSS", true, 975, 102, 200 )
--}
AddDungeon( "WI_INSTANCE_SANPRES" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(60) )
	
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 1961, 100, 258 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 879, 100, 168 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 800, 100, 228 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 773, 100, 223 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 930, 100, 210 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 2002, 100, 264 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH", true, 1920, 100, 269 )
	
	SetMonster( ID_BOSS, "MI_SHIPHARPINEES", true, 1367, 108, 1731 )
	SetMonster( ID_BOSS, "MI_NIANSHOU", true, 1367, 108, 1731 )
	SetMonster( ID_BOSS, "MI_SKELDEVIL", true, 1367, 108, 1731 )
--}

AddDungeon( "WI_INSTANCE_SANPRES_1" )
--{
	SetClass( CLASS_NORMAL, CLASS_MASTER, CLASS_HERO )
	SetLevel( 1, 200 )
	SetCoolTime( MIN(60) )
	
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 1961, 100, 258 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 879, 100, 168 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 800, 100, 228 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 773, 100, 223 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 930, 100, 210 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 2002, 100, 264 )
	SetMonster( ID_MIDBOSS, "MI_SHIPHIPPOGRIPH_1", true, 1920, 100, 269 )
	
	SetMonster( ID_BOSS, "MI_SHIPHARPINEES_1", true, 1367, 108, 1731 )
	SetMonster( ID_BOSS, "MI_NIANSHOU", true, 1367, 108, 1731 )
	SetMonster( ID_BOSS, "MI_SKELDEVIL", true, 1367, 108, 1731 )
--}